# beetlejuice
Summon beetlejuice! Please use g++ -o beetlejuice beetlejuice.cpp followed by vim/nano/whatever ~/.bashrc and add alias BEETLEJUICE="./beetlejuice" and then reboot for full effect.
